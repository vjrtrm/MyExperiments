Towers of Hanoi canvas game.
===========

Just basic mechanics with drag'n'drop and game logic.

Demo page: http://johnner.github.com/Canvas-Tower-of-Hanoi/

###Inspired by
[@simonsarris](https://twitter.com/simonsarris)
