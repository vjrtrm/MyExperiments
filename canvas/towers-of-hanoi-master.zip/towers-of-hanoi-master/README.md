Towers of Hanoi
===============

An HTML5 Canvas implementation of the classic math puzzle.
----------------------------------------------------------

Towers of Hanoi is an implementation of the classic Towers of Hanoi puzzle
using HTML5 Canvas.  Given the ability to play with a user-specified number of
disks, the user quickly gains an appreciation for how the number of steps
required to reach a solution grows exponentially with the number of disks.
